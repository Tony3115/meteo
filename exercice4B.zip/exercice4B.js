for (let cpt = 0; cpt <= 10; cpt = cpt + 1) {
    const result = cpt * 3;
    console.log(`${3} * ${cpt} = ${result}`)
}

