let a = 6
if (a > 5) {
    alert("a est plus grand que 5")
} else {
    alert("a est plus petit que 5")
}

alert(a > 5 ? "a est plus grand que 5" : "a est plus petit que 5")