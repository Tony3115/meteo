function calculerSurface(longueur, largeur) {
    return longueur * largeur;
}

let longueur = 5;
let largeur = 6;
let surface = calculerSurface(largeur, longueur);
console.log(`"le terrain a une largeur de ${largeur} et une longeur de ${longueur}, et a une surface de ${surface} m2"`)




