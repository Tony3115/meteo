let obj = {
    nom: "Sa bento",
    prenom: "Tony",
    age: 29,
    sexe: "Masculin",
    adresse: "Cugnaux",
    paysDeRésidence: "France",
    diplômesPossédes: ["Brevet", "Bac pro"]
}

console.log(obj["diplômesPossédes"]);