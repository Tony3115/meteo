function fonction1() {
    console.log("la fusée est arrivée")
}

function fonction2() {
    console.log("le lièvre est arrivée")
}

setInterval(fonction1, 1000,)
setInterval(fonction2, 1000,)
console.log("la tortue est arrivée premier")