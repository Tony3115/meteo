let var1 = [1, 2, 3, 4, 5, 6]
let var2 = [
    "Toto",
    "Jean",
    "Dupont"
]
let var3 = [
    { nom: "Jean", age: 23 },
    { nom: "Sophie", age: 30 },
    { nom: "Jacques", age: 12 }
]
let var4 = [
    ["Renault", "Peugeot"],
    ["Audi", "BMW"],
    ["Fiat", "Ferrari"],
]

let obj = { nom: "Jean", age: 23 }
let propriete = 'age'

for (let i = 0; i < var4.length; i = i + 1) {

    console.log(var4[i])
}