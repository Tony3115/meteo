/*let slitChaine = (machaine) => {
    return machaine.split(' ');
}*/

function slitChaine(machaine) {
    return machaine.split(' ');
}

console.log(slitChaine('Bonjour, ca va '));