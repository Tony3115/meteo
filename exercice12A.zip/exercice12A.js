setInterval(function () {
    console.log("Bonjour");
}, 1000);
